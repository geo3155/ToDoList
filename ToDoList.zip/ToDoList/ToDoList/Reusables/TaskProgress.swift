//
//  TaskProgress.swift
//  ToDoList
//
//  Created by George Predan on 04.03.2024.
//

import SwiftUI

struct TaskProgress: View {
    
    var progress: Progress
    var type: ProgressType = .simple
    
    private var text: String {
        switch progress {
        case .upcoming:
            "Upcoming"
        case .pending:
            "Pending"
        case .completed:
            "Completed"
        }
    }
    private var color: Color {
        switch progress {
        case .upcoming:
                .red
        case .pending:
                .yellow
        case .completed:
                .green
        }
    }
    
    var body: some View {
        switch type {
        case .simple:
            simple
        case .streched:
            streched
        }
    }
    
    private var simple: some View {
        RoundedRectangle(cornerRadius: 10)
            .fill(color)
            .frame(width: 100, height: 45)
            .overlay {
                Text(text)
                    .foregroundStyle(.white)
                    .bold()
            }
    }
    
    private var streched: some View {
        VStack {
            HStack(spacing: 0) {
                RoundedRectangle(cornerRadius: 10)
                    .fill(color)
                RoundedRectangle(cornerRadius: 10)
            }
            .frame(height: 5)
            .padding(.horizontal)
            Text(text)
                .font(.title3)
                .foregroundStyle(.black)
                .shadow(color: color, radius: 1)
        }
    }
    
    enum ProgressType {
        case simple
        case streched
    }
}

#Preview {
    TaskProgress(progress: .pending, type: .streched)
}
