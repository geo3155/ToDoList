//
//  AddButton.swift
//  ToDoList
//
//  Created by George Predan on 04.03.2024.
//

import SwiftUI

struct AddButton: View {
    let action: () -> Void
    var body: some View {
        Button {
            action()
        } label: {
            Circle()
                .fill(.indigo)
                .frame(width: 60, height: 60)
                .overlay {
                    Image(systemName: "plus")
                        .resizable()
                        .scaledToFit()
                        .foregroundStyle(.white)
                        .frame(width: 40, height: 40)
            }
        }
        .buttonStyle(.plain)
    }
}

#Preview {
    AddButton {
        
    }
}
