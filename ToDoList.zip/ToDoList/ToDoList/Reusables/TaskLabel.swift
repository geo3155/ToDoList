//
//  TaskLabel.swift
//  ToDoList
//
//  Created by George Predan on 04.03.2024.
//

import SwiftUI

struct TaskLabel: View {
  let toDo: ToDo
  var body: some View {
    HStack {
      Text(toDo.name)
        .font(.title3)
      Spacer()
      TaskProgress(progress: toDo.progress)
    }
    .padding()
    .background {
      RoundedRectangle(cornerRadius: 10)
        .fill(.white)
        .shadow(radius: 5)
    }
  }
}

#Preview {
  TaskLabel(toDo: ToDo(name: "Do the dishes", progress: .completed))
}
