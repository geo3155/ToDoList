//
//  SwipeToDelete.swift
//  ToDoList
//
//  Created by George Predan on 22.04.2024.
//

import SwiftUI

struct SwipeToDeleteViewModifier: ViewModifier {
  
  let onDelete: () -> Void
  
  private var showDelete: Bool {
    xOffset <= -40
  }
  @State private var xOffset: CGFloat = .zero
  
  func body(content: Content) -> some View {
    HStack {
      content
        .gesture(DragGesture()
          .onChanged({ currentValue in
            let currentOffset = currentValue.translation.width
            if currentOffset > 0 {
              return
            }
            xOffset = currentValue.translation.width
            print(xOffset)
          })
          .onEnded({ endedValue in
            let endedOffset = endedValue.translation.width
            if endedOffset <= -130 {
              withAnimation(.snappy) {
                onDelete()
              }
            } else if endedOffset <= -40 {
              xOffset = -40
              return
            }
            xOffset = 0
          })
        )
        .offset(x: xOffset)
      
      if showDelete {
        button
          .offset(x: xOffset / 1.6)
          .transition(.opacity)
      }
    }
    .animation(.snappy, value: xOffset)
    .animation(.snappy, value: showDelete)
  }
  
  private var button: some View {
    Button {
      withAnimation(.snappy) {
        onDelete()
      }
    } label: {
      Image(systemName: "xmark")
        .foregroundStyle(.white)
        .padding(12)
        .background {
          Color.red
            .clipShape(Circle())
        }
    }
  }
}

#Preview {
  TaskLabel(toDo: ToDo(name: "Some task"))
    .modifier(SwipeToDeleteViewModifier(onDelete: {}))
    .padding(.horizontal)
}

extension View {
  func swipeToDelete(_ delete: @escaping () -> Void) -> some View {
    self.modifier(SwipeToDeleteViewModifier(onDelete: delete))
  }
}
