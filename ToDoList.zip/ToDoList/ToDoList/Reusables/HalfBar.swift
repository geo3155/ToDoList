//
//  HalfBar.swift
//  ToDoList
//
//  Created by George Predan on 04.03.2024.
//

import SwiftUI

struct HalfBar: View {
    var body: some View {
        HStack(spacing: 0) {
            RoundedRectangle(cornerRadius: 10)
            Rectangle()
        }
        .frame(height: 5)
    }
}

#Preview {
    HalfBar()
}
