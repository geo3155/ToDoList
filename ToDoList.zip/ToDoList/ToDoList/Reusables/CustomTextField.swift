//
//  CustomTextField.swift
//  ToDoList
//
//  Created by George Predan on 05.03.2024.
//

import SwiftUI

struct CustomTextField: View {
    @Binding var text: String
    var type: String = ""
    var body: some View {
        TextField("\(type)", text: $text)
            .font(.title)
            .padding()
            .foregroundStyle(.black)
            .background {
              RoundedRectangle(cornerRadius: 20)
                .fill(.gray.opacity(0.2))
                .stroke(Color.black, lineWidth: 2.0)
            }
    }
}

#Preview {
    CustomTextField(text: .constant(""), type: "Title")
}
