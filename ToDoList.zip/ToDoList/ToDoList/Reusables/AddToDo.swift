//
//  AddToDo.swift
//  ToDoList
//
//  Created by George Predan on 05.03.2024.
//

import SwiftUI

struct AddToDo: View {
  
  @Binding var title: String
  @Binding var progress: Progress
  let dismiss: () -> Void
  
  var body: some View {
    NavigationStack {
      VStack {
        CustomTextField(text: $title)
        Spacer()
        ModifyProgress(progress: $progress)
      }
      .padding()
      .toolbar {
        ToolbarItem(placement: .topBarTrailing) {
          Button {
            dismiss()
          } label: {
            Text(title.isEmpty ? "Close" : "Save")
          }
        }
      }
      .navigationTitle("Title")
    }
  }
}

#Preview {
  AddToDo(title: .constant(""), progress: .constant(.completed), dismiss: {})
}
