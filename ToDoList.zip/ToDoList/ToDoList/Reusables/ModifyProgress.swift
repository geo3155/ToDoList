//
//  ModifyProgress.swift
//  ToDoList
//
//  Created by George Predan on 20.04.2024.
//

import SwiftUI

struct ModifyProgress: View {
    
    @Binding var progress: Progress
    let title: String = ""
    
    private(set) var progressCases: [Progress] = [.upcoming, .pending, .completed]
    
    var body: some View {
        Picker(title, selection: $progress) {
            ForEach(progressCases, id: \.self) {
                Text($0.rawValue)
            }
        }
        .pickerStyle(.palette)
    }
}

#Preview {
    ModifyProgress(progress: .constant(.completed))
}
