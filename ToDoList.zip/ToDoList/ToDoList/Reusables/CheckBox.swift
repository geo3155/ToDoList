//
//  CheckBox.swift
//  ToDoList
//
//  Created by George Predan on 04.03.2024.
//

import SwiftUI

struct CheckBox: View {
    @State var isChecked: Bool = false
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 5)
                .stroke(lineWidth: 2.5)
                .frame(width: 30, height: 30)
            if isChecked {
                Image(systemName: "checkmark")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 25, height: 25)
                    .foregroundStyle(.orange)
            }
        }
        .animation(.default, value: isChecked)
        .onTapGesture {
            isChecked.toggle()
        }
    }
}

#Preview {
    CheckBox()
}
