//
//  NoTaskView.swift
//  ToDoList
//
//  Created by George Predan on 25.04.2024.
//

import SwiftUI

struct NoTaskView: View {
  var body: some View {
    RoundedRectangle(cornerRadius: 10)
      .fill(.gray.opacity(0.4))
      .frame(height: 75)
      .shadow(radius: 5)
      .padding(.vertical)
      .overlay {
        Text("Add a task to continue")
          .font(.title3)
      }
  }
}

#Preview {
  NoTaskView()
}
