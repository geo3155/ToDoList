//
//  ViewModel.swift
//  ToDoList
//
//  Created by George Predan on 04.03.2024.
//r

import Foundation
import SwiftUI

class ViewModel: ObservableObject {
  var path = NavigationPath()
//  @Published var selectedToDo: ToDo?
  @Published var toDos: [ToDo] = [ToDo(name: "Some usessless task"), ToDo(name: "Antoher one")]
  @Published var showSheet: Bool = false
  @Published var title: String = ""
  @Published var description = ""
  @Published var progress: Progress = .upcoming
  
  func deleteToDo(_ toDo: ToDo) {
    //        path.removeLast()
    toDos.remove(toDo)
  }
  
  init() {
    let toDoCache = JsonCache()
    
    do {
      try toDoCache.writeToCache(elemnent: toDos.first!, path: (toDoCache.applicationSharedCollection?.appending(path: "toDo").absoluteString)!)
    } catch {
      print(error.localizedDescription)
    }
  }
  
  func addToDo() {
    guard !title.isEmpty else {
      return
    }
    toDos.append(ToDo(name: title, progress: progress, description: description))
    //        updateUserDefaults()
    title = ""
    description = ""
    progress = .upcoming
  }
  
  //    func updateUserDefaults() {
  //        UserDefaults.standard.set(toDos, forKey: "ToDos")
  //    }
}

extension Array where Element == ToDo {
  mutating func remove(_ toDo: Element) {
    for (index, element) in self.enumerated() {
      if element == toDo {
        remove(at: index)
      }
    }
  }
}
