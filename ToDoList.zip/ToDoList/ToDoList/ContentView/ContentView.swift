//
//  ContentView.swift
//  ToDoList
//
//  Created by George Predan on 04.03.2024.
//

import SwiftUI

struct ContentView: View {
  @StateObject private var viewModel = ViewModel()
  var body: some View {
    NavigationStack(path: $viewModel.path) {
      VStack {
        Divider()
        ZStack {
          ScrollView {
            VStack {
              if viewModel.toDos.isEmpty {
                NoTaskView()
              }
              ForEach(viewModel.toDos, id: \.name) { toDo in
                NavigationLink(value: toDo) {
                  TaskLabel(toDo: toDo)
                    .lineLimit(1)
                    .swipeToDelete({viewModel.deleteToDo(toDo)})
                    .foregroundStyle(.black)
                }
              }
            }
            .padding()
          }
          .scrollDisabled(viewModel.toDos.isEmpty)
          button
            .animation(.default, value: viewModel.toDos.isEmpty)
            .sheet(isPresented: $viewModel.showSheet, onDismiss: viewModel.addToDo) {
              AddToDo(title: $viewModel.title, progress: $viewModel.progress) { viewModel.showSheet.toggle() }
            }
            .navigationTitle("To do List")
            .navigationDestination(for: ToDo.self) { todo in
              TaskView(toDo: toDoBinding(for: todo)) {
                viewModel.deleteToDo(todo)
                viewModel.path.removeLast()
              }
            }
        }
      }
    }
  }
  
  private var button: some View {
    VStack {
      Spacer()
      HStack {
        Spacer()
        AddButton {
          viewModel.showSheet.toggle()
        }
      }
      .padding()
    }
  }
  
  private func toDoBinding(for toDo: ToDo) -> Binding<ToDo> {
    guard let toDoIndex = viewModel.toDos.firstIndex(where: { $0.id == toDo.id }) else {
      return .constant(toDo)
    }
    return Binding {
      viewModel.toDos[toDoIndex]
    } set: { updatedToDo in
      viewModel.toDos[toDoIndex] = updatedToDo
    }
  }
}

#Preview {
  ContentView()
}


