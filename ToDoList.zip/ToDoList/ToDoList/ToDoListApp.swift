//
//  ToDoListApp.swift
//  ToDoList
//
//  Created by George Predan on 04.03.2024.
//

import SwiftUI

@main
struct ToDoListApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
            .onAppear {
              JsonCache().applicationSharedCollection
            }
        }
    }
}
