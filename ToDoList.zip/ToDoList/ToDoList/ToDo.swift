//
//  ToDo.swift
//  ToDoList
//
//  Created by George Predan on 04.03.2024.
//

import Foundation

struct ToDo: Identifiable, Hashable, Codable {
  let id = UUID()
  var name: String
  var progress: Progress = .upcoming
  var description = ""
  
  mutating func updateProgress(_ progress: Progress) {
    self.progress = progress
  }
}

enum Progress: String, Hashable, CaseIterable, Codable {
  case upcoming
  case pending
  case completed
}
