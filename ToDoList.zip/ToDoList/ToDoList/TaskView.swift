//
//  TaskView.swift
//  ToDoList
//
//  Created by George Predan on 04.03.2024.
//

import SwiftUI

struct TaskView: View {
  
  @Binding var toDo: ToDo
  let onDeleteAction: () -> Void
  var body: some View {
    VStack {
      VStack (alignment: .leading) {
        Text("Modify task progress: ")
          .font(.title2)
          .bold()
        ModifyProgress(progress: $toDo.progress)
      }
      Spacer()
      Button {
        onDeleteAction()
      } label: {
        Text("Delete")
          .foregroundStyle(.red)
          .font(.title3)
      }
      .buttonStyle(.plain)
      .padding(.horizontal)
      .navigationBarTitleDisplayMode(.inline)
      .navigationTitle($toDo.name)
    }
    .padding()
  }
}

#Preview {
  TaskView(toDo: .constant(ToDo(name: "Hello", description: "This is a description")), onDeleteAction: {})
}
