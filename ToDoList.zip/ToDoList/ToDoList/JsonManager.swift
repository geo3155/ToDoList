//
//  JsonManager.swift
//  ToDoList
//
//  Created by George Predan on 12.05.2024.
//

import Foundation


struct JsonCache {
  
  var applicationSharedCollection: URL? {
    FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first?.appending(path: "cache")
  }
  
  func readFromCache<T: Codable>(path: String) throws -> T {
    guard FileManager.default.fileExists(atPath: path) else {
      throw JsonCacheException.fileNotFound
    }
    guard FileManager.default.isReadableFile(atPath: path) else {
      throw JsonCacheException.fileNotFound
    }
    
    let cacheData = try Data.init(contentsOf: URL(filePath: path))
    
    return try JSONDecoder().decode(T.self, from: cacheData)
  }
  
  func writeToCache<T: Codable>(elemnent: T, path: String) throws {
    let dataToCache = try JSONEncoder().encode(elemnent)
    
    if !FileManager.default.fileExists(atPath: path) {
      try FileManager.default.createDirectory(at: URL(filePath:path), withIntermediateDirectories: true)
    }
    
    try dataToCache.write(to: URL(filePath:path))
  }
  
}

enum JsonCacheException: Error {
  case fileNotFound
}
